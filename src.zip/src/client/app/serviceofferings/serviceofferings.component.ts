import { Component } from '@angular/core';

/**
*	This class represents the lazy loaded ServiceOfferingsComponent.
*/

@Component({
	moduleId: module.id,
	selector: 'dashboard-cmp',
	templateUrl: 'serviceofferings.component.html'
})

export class ServiceOfferingsComponent { }
