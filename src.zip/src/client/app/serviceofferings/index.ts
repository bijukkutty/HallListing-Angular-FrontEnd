/**
*	This barrel file provides the export for the lazy loaded ServiceOfferingsComponent.
*/
export * from './serviceofferings.component';
export * from './serviceofferings.routes';
