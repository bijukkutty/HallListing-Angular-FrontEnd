export class Detail {
    soDetailPropertyName: string;
    soDetailPropertyTagline: string;
    soDetailPropertyAddr: string;
    soDetailImage: string;
    soDetailSelf: string;
}
