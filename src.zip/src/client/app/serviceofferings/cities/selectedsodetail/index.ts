/**
 * This barrel file provides the export for the lazy loaded CityComponent.
 */
export * from './selsodetail.component';
export * from './selsodetail.routes';
