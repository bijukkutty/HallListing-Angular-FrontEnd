export class Image {
    soImage: string;
}
