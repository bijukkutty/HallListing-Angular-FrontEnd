import { Route } from '@angular/router';

import { SelSoDetailComponent } from './selsodetail.component';

export const SoDetailRoutes: Route[] = [
	{
		path: 'selsodetail',
		component: SelSoDetailComponent
	}
];
