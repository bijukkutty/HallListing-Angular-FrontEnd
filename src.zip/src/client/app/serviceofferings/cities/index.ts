/**
 * This barrel file provides the export for the lazy loaded CityComponent.
 */
export * from './cities.component';
export * from './cities.routes';
