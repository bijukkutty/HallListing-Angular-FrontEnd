export class Location {
    soLocationName: string;
    soLocationSelf: string;
}
