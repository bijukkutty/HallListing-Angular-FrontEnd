export class City {
    soCityName: string;
    soCitySelf: string;
}
