import { Component, Input } from '@angular/core';
import { City } from './City';

@Component({
    selector: 'locations-cmp',
    templateUrl: `<ul>
  <li>Coffee</li>
  <li>Tea</li>
  <li>Milk</li>
</ul>`
})

export class LocationComponent { }
