export class Country {
    soCountryName: string;
}
