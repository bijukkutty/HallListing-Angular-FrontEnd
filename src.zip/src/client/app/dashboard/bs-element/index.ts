/**
 * This barrel file provides the export for the lazy loaded BSelementComponent.
 */
export * from './bsElement.component';
export * from './bsElement.routes';
