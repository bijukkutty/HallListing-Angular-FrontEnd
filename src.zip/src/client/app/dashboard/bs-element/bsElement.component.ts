import { Component } from '@angular/core';

@Component({
	moduleId: module.id,
    selector: 'bs-element',
    templateUrl: './bs-element.component.html'
})

export class BSElementComponent {}
