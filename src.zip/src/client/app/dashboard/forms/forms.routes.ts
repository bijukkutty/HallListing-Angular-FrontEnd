import { Route } from '@angular/router';

import { FormComponent } from './index';

export const FormRoutes: Route[] = [
	{
		path: 'forms',
		component: FormComponent
	},
];
